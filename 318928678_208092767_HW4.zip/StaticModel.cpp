#include "StaticModel.h"
#include <iostream>

